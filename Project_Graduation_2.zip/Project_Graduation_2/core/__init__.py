"""
Core modules for Coca-Cola Sorting System
"""

__version__ = "2.0.0"
__author__ = "Coca-Cola Sorting Team"
