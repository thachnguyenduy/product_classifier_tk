"""Hardware control helpers for Raspberry Pi + Arduino."""
from __future__ import annotations

import platform
import time
from dataclasses import dataclass
from typing import Optional

try:
    import RPi.GPIO as GPIO  # type: ignore
except Exception:  # pragma: no cover - not available on non-Pi systems
    GPIO = None

try:
    import serial  # type: ignore
except Exception:  # pragma: no cover
    serial = None


def is_raspberry_pi() -> bool:
    """Return True when running on Raspberry Pi hardware."""
    return "raspberrypi" in platform.uname().node.lower()


@dataclass
class HardwarePins:
    relay_pin: int = 17
    servo_pin: int = 18


class HardwareController:
    """Provides safe wrappers over GPIO + Arduino serial calls."""

    def __init__(self, pins: HardwarePins | None = None, serial_port: str = "/dev/ttyACM0") -> None:
        self.pins = pins or HardwarePins()
        self.serial_port = serial_port
        self.available = is_raspberry_pi() and GPIO is not None
        self.serial_conn: Optional[serial.Serial] = None if serial is None else self._open_serial()

        if self.available:
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(self.pins.relay_pin, GPIO.OUT, initial=GPIO.LOW)
            GPIO.setup(self.pins.servo_pin, GPIO.OUT)
            self.servo_pwm = GPIO.PWM(self.pins.servo_pin, 50)
            self.servo_pwm.start(0)
        else:
            self.servo_pwm = None

    def _open_serial(self) -> Optional["serial.Serial"]:
        if serial is None:
            return None
        try:
            return serial.Serial(self.serial_port, 9600, timeout=1)
        except Exception:
            return None

    def start_conveyor(self) -> None:
        try:
            if self.available:
                GPIO.output(self.pins.relay_pin, GPIO.HIGH)
            print("Conveyor started.")
        except Exception as exc:
            print(f"Conveyor start failed: {exc}")

    def stop_conveyor(self) -> None:
        try:
            if self.available:
                GPIO.output(self.pins.relay_pin, GPIO.LOW)
            print("Conveyor stopped.")
        except Exception as exc:
            print(f"Conveyor stop failed: {exc}")

    def push_bad_product(self) -> None:
        """Rotate a servo for ~1 second to reject a bad product."""
        try:
            if self.available and self.servo_pwm:
                self._set_servo_angle(90)
                time.sleep(1)
                self._set_servo_angle(0)
            print("Bad product ejected.")
        except Exception as exc:
            print(f"Servo action failed: {exc}")

    def _set_servo_angle(self, angle: float) -> None:
        duty = 2 + (angle / 18)
        if self.servo_pwm:
            self.servo_pwm.ChangeDutyCycle(duty)
            time.sleep(0.3)
            self.servo_pwm.ChangeDutyCycle(0)

    def hardware_test(self) -> None:
        """Quick relay + servo + serial ping test."""
        self.start_conveyor()
        time.sleep(0.5)
        self.stop_conveyor()
        self.push_bad_product()
        if self.serial_conn:
            try:
                self.serial_conn.write(b"ping\n")
                print("Sent ping to Arduino.")
            except Exception as exc:
                print(f"Serial write failed: {exc}")

    def cleanup(self) -> None:
        if self.available:
            GPIO.cleanup()
        if self.serial_conn:
            self.serial_conn.close()

