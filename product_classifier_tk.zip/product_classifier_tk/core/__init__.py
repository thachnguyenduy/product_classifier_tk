"""Core modules for the Tkinter classifier."""

