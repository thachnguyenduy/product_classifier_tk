"""UI package for the Tkinter classifier."""

