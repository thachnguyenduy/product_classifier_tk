# Core modules for Coca-Cola Sorting System

